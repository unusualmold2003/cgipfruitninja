import mediapipe as mp
import cv2
import win32api
import pyautogui
import math

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

video = cv2.VideoCapture(0)

def calculate_distance(point1, point2):
    return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

with mp_hands.Hands(min_detection_confidence=0.8, min_tracking_confidence=0.5) as hands:
    while video.isOpened():
        _, frame = video.read()
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = cv2.flip(image, 1)
        image_height, image_width, _ = image.shape
        results = hands.process(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        if results.multi_hand_landmarks:
            for num, hand in enumerate(results.multi_hand_landmarks):
                mp_drawing.draw_landmarks(
                    image, hand, mp_hands.HAND_CONNECTIONS,
                    mp_drawing.DrawingSpec(color=(250, 44, 250), thickness=2, circle_radius=2)
                )

                landmark_positions = {}
                for point in mp_hands.HandLandmark:
                    normalized_landmark = hand.landmark[point]
                    pixel_coordinates = mp_drawing._normalized_to_pixel_coordinates(
                        normalized_landmark.x, normalized_landmark.y, image_width, image_height
                    )
                    if pixel_coordinates:
                        landmark_positions[point] = pixel_coordinates

                if (mp_hands.HandLandmark.INDEX_FINGER_TIP in landmark_positions and
                        mp_hands.HandLandmark.THUMB_TIP in landmark_positions):
                    index_finger_tip = landmark_positions[mp_hands.HandLandmark.INDEX_FINGER_TIP]
                    thumb_tip = landmark_positions[mp_hands.HandLandmark.THUMB_TIP]

                    cv2.circle(image, index_finger_tip, 25, (0, 200, 0), 5)
                    cv2.circle(image, thumb_tip, 25, (0, 0, 200), 5)

                    win32api.SetCursorPos((index_finger_tip[0] * 4, index_finger_tip[1] * 5))

                    distance = calculate_distance(index_finger_tip, thumb_tip)
                    if distance < 40:
                        pyautogui.mouseDown(button='left')
                    else:
                        pyautogui.mouseUp(button='left')

        cv2.imshow('game', image)
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

video.release()
cv2.destroyAllWindows()
